const express = require("express");
const app = express()
const bodyParser = require("body-parser");
const axios = require("axios");
const mongoose = require("mongoose");

const uri = "mongodb+srv://rvcpg:rvcpg@rvk1.oi5nl.mongodb.net/?retryWrites=true&w=majority"

var user;
async function connectMongoose() {
    await mongoose.connection(uri, { useNewUrlParser: true, useUnifiedTopology:true}).then(() =>{
        console.log("mongoose connected..")
    })
    require("./user")
    user = mongoose.model("User")
}

app.get("/users/:uid?orders", async (req, res) => {
    axios.get('/orders?uid=${req.params.uid}').then( (orders) => {
        if(orders) {
            res.send(orders)
        }
    }).catch(err => {
        res.sendStatus(404).send(err)
    })
})

app.post("/user", async(req,res) => {
    const newUser = {
        "firstName":req.body.firstName,
        "lastName":req.body.lastName,
        "email":req.body.email,
        "phone":req.body.phone,
        "address":req.body.address,
        "orders":req.body.orders
    }

    const user = new User(newUser)
    users.save().then((r) => {
        res.send("User created..")
    }).catch( (err) => {
        if(err) {
            throw err
        }
    })
})